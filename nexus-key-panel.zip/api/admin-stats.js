import {db,json,adminFrom} from "./_lib.js";
export default async function handler(req,res){
  if(req.method!=="POST") return json(res,405,{error:"Method not allowed"});
  try{
    const admin=await adminFrom(req); if(!admin) return json(res,403,{error:"Admin access required"});
    const {data,error}=await db.from("licenses").select("status");
    if(error) throw error;
    const rows=data||[];
    return json(res,200,{total_keys:rows.length,active_keys:rows.filter(x=>x.status==="active").length,banned_keys:rows.filter(x=>x.status==="banned").length});
  }catch(e){return json(res,500,{error:"Could not load statistics"});}
}