import {db,json} from "./_lib.js";
export default async function handler(req,res){
  if(req.method!=="POST") return json(res,405,{valid:false,error:"Method not allowed"});
  try{
    const key=String(req.body?.key||"").trim().toUpperCase(), hwid=String(req.body?.hwid||"").trim();
    if(!key||!hwid||key.length>80||hwid.length>200) return json(res,400,{valid:false,error:"Key and device ID are required"});
    const {data:license,error}=await db.from("licenses").select("id,status,expires_at,hwid").eq("key",key).maybeSingle();
    if(error||!license) return json(res,200,{valid:false,error:"Invalid key"});
    if(license.status==="banned") return json(res,200,{valid:false,error:"License banned"});
    if(license.expires_at&&new Date(license.expires_at).getTime()<Date.now()) return json(res,200,{valid:false,error:"License expired"});
    if(license.hwid&&license.hwid!==hwid) return json(res,200,{valid:false,error:"Key is already bound to another device"});
    if(!license.hwid){
      const {data:updated,error:updateError}=await db.from("licenses").update({hwid,status:"active"}).eq("id",license.id).is("hwid",null).select("id").maybeSingle();
      if(updateError||!updated) return json(res,409,{valid:false,error:"Could not bind device; retry"});
    }
    return json(res,200,{valid:true,status:"active",expires_at:license.expires_at});
  }catch(e){return json(res,500,{valid:false,error:"Verification service error"});}
}