import {db,json,adminFrom} from "./_lib.js";
export default async function handler(req,res){
  if(req.method!=="POST") return json(res,405,{error:"Method not allowed"});
  try{
    const admin=await adminFrom(req); if(!admin) return json(res,403,{error:"Admin access required"});
    const {data,error}=await db.from("licenses").select("id,key,status,expires_at,created_at,hwid").order("created_at",{ascending:false}).limit(500);
    if(error) throw error;
    return json(res,200,{keys:data||[]});
  }catch(e){return json(res,500,{error:"Could not load licenses"});}
}