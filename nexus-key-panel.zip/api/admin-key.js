import {db,json,adminFrom} from "./_lib.js";
export default async function handler(req,res){
  if(req.method!=="POST") return json(res,405,{error:"Method not allowed"});
  try{
    const admin=await adminFrom(req); if(!admin) return json(res,403,{error:"Admin access required"});
    const {action,id}=req.body||{}; if(!id||!["ban","unban","reset"].includes(action)) return json(res,400,{error:"Invalid action"});
    const patch=action==="ban"?{status:"banned"}:action==="unban"?{status:"unused"}:{hwid:null,user_id:null,status:"unused"};
    const {error}=await db.from("licenses").update(patch).eq("id",id); if(error) throw error;
    return json(res,200,{success:true});
  }catch(e){return json(res,500,{error:"Could not update license"});}
}