import React, { useEffect, useState } from "react";
import { supabase } from "./lib/supabase";
import { Shield, KeyRound, LayoutDashboard, LogOut, Copy, RefreshCw, Plus, Ban, Smartphone, Activity } from "lucide-react";

const api = async (path, token, body={}) => {
  const r = await fetch(`/api/${path}`, {method:"POST", headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`}, body:JSON.stringify(body)});
  const data = await r.json().catch(()=>({error:"Invalid server response"}));
  if (!r.ok) throw new Error(data.error || "Request failed");
  return data;
};
function App(){
  const [session,setSession]=useState(null), [mode,setMode]=useState("login"), [email,setEmail]=useState(""), [password,setPassword]=useState("");
  const [tab,setTab]=useState("overview"), [profile,setProfile]=useState(null), [keys,setKeys]=useState([]), [stats,setStats]=useState(null);
  const [message,setMessage]=useState(""), [busy,setBusy]=useState(false), [duration,setDuration]=useState("7"), [quantity,setQuantity]=useState(1);
  useEffect(()=>{ if(!supabase){setMessage("Add your Supabase environment variables to start.");return;}
    supabase.auth.getSession().then(({data})=>setSession(data.session));
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));
    return ()=>subscription.unsubscribe();
  },[]);
  useEffect(()=>{if(session) load();},[session]);
  async function load(){
    try{
      const {data:p}=await supabase.from("profiles").select("*").eq("id",session.user.id).single();
      setProfile(p);
      if(p?.role==="admin"){
        const [all,summary]=await Promise.all([api("admin-list",session.access_token),api("admin-stats",session.access_token)]);
        setKeys(all.keys||[]); setStats(summary);
      } else {
        const {data:k}=await supabase.from("licenses").select("id,key,status,expires_at,created_at,hwid").eq("user_id",session.user.id).order("created_at",{ascending:false}).limit(100);
        setKeys(k||[]);
      }
    }catch(e){setMessage(e.message);}
  }
  async function auth(e){
    e.preventDefault(); setBusy(true); setMessage("");
    try{
      const result=mode==="signup" ? await supabase.auth.signUp({email,password}) : await supabase.auth.signInWithPassword({email,password});
      if(result.error) throw result.error;
      if(mode==="signup" && !result.data.session) setMessage("Account created. Check your email to confirm, then sign in.");
    }catch(e){setMessage(e.message);}finally{setBusy(false);}
  }
  async function act(fn){setBusy(true);setMessage("");try{await fn();await load();}catch(e){setMessage(e.message);}finally{setBusy(false);}}
  async function createKeys(){await act(async()=>{const d=await api("admin-create",session.access_token,{duration_days:Number(duration),quantity:Number(quantity)});setMessage(`${d.created} license key(s) generated.`);});}
  async function keyAction(action,id){await act(async()=>{await api("admin-key",session.access_token,{action,id});});}
  async function signOut(){await supabase.auth.signOut();setProfile(null);setKeys([]);}
  if(!supabase) return <main className="center"><div className="auth card"><Logo/><h2>Configuration required</h2><p>Copy <code>.env.example</code> to <code>.env.local</code> and add your Supabase URL and anon key.</p></div></main>;
  if(!session) return <main className="center"><form className="auth card" onSubmit={auth}><Logo/><p className="muted">LICENSE MANAGEMENT CONSOLE</p><h1>{mode==="login"?"Welcome back":"Create account"}</h1><label>Email</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/><label>Password</label><input type="password" minLength="8" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/><button className="primary full" disabled={busy}>{busy?"Please wait…":mode==="login"?"Sign in":"Create account"}</button><button type="button" className="link full" onClick={()=>setMode(mode==="login"?"signup":"login")}>{mode==="login"?"New here? Create account":"Already registered? Sign in"}</button>{message&&<p className="notice">{message}</p>}</form></main>;
  const admin=profile?.role==="admin";
  return <div className="shell"><aside className="sidebar"><Logo/><div className="navlabel">WORKSPACE</div><button className={tab==="overview"?"nav active":"nav"} onClick={()=>setTab("overview")}><LayoutDashboard size={18}/> Overview</button><button className={tab==="keys"?"nav active":"nav"} onClick={()=>setTab("keys")}><KeyRound size={18}/> {admin?"License keys":"My license"}</button>{admin&&<button className={tab==="admin"?"nav active":"nav"} onClick={()=>setTab("admin")}><Shield size={18}/> Admin tools</button>}<div className="sidebottom"><div className="userline"><div className="avatar">{session.user.email?.[0]?.toUpperCase()}</div><div><b>{session.user.email}</b><small>{admin?"Administrator":"User account"}</small></div></div><button className="nav" onClick={signOut}><LogOut size={18}/> Sign out</button></div></aside>
  <main className="content"><header><div><p className="eyebrow">NEXUS / CONTROL CENTER</p><h1>{tab==="overview"?"Dashboard":tab==="keys"?"License management":"Admin tools"}</h1></div><span className="status"><i/> SYSTEM ONLINE</span></header>
  {message&&<div className="notice">{message}<button onClick={()=>setMessage("")}>×</button></div>}
  {tab==="overview"&&<><div className="welcome"><div><p className="eyebrow">GOOD TO SEE YOU</p><h2>Welcome to your command center.</h2><p className="muted">Manage device access and license status from one place.</p></div><div className="glow"><Shield size={54}/></div></div><div className="stats"><Stat icon={<KeyRound/>} label="Visible licenses" value={keys.length}/><Stat icon={<Activity/>} label="Account role" value={admin?"ADMIN":"USER"}/><Stat icon={<Smartphone/>} label="Bound devices" value={keys.filter(k=>k.hwid).length}/></div><section className="card section"><h3>Recent licenses</h3><KeyTable keys={keys.slice(0,5)} admin={admin} action={keyAction}/></section></>}
  {tab==="keys"&&<section className="card section"><div className="sectionhead"><div><h2>{admin?"All license keys":"Your license keys"}</h2><p className="muted">Keys are validated by the server, not by the browser.</p></div><button className="secondary" onClick={()=>load()}><RefreshCw size={16}/> Refresh</button></div><KeyTable keys={keys} admin={admin} action={keyAction}/></section>}
  {tab==="admin"&&admin&&<><div className="stats"><Stat icon={<KeyRound/>} label="Total keys" value={stats?.total_keys??keys.length}/><Stat icon={<Activity/>} label="Active keys" value={stats?.active_keys??"—"}/><Stat icon={<Ban/>} label="Banned keys" value={stats?.banned_keys??"—"}/></div><section className="card section"><h2>Generate license keys</h2><p className="muted">Create random keys with server-side authorization.</p><div className="formrow"><div><label>Duration</label><select value={duration} onChange={e=>setDuration(e.target.value)}><option value="1">1 day</option><option value="7">7 days</option><option value="30">30 days</option><option value="36500">Lifetime</option></select></div><div><label>Quantity (1–50)</label><input type="number" min="1" max="50" value={quantity} onChange={e=>setQuantity(e.target.value)}/></div><button className="primary" onClick={createKeys} disabled={busy}><Plus size={17}/> Generate keys</button></div></section><section className="card section"><h2>Administration</h2><p className="muted">Ban, unban or clear a device binding from the license list.</p><KeyTable keys={keys} admin={true} action={keyAction}/></section></>}</main></div>;
}
function Logo(){return <div className="brand"><div className="brandicon"><KeyRound/></div><div><b>NEXUS</b><small>KEY PANEL</small></div></div>}
function Stat({icon,label,value}){return <div className="card stat"><div className="staticon">{icon}</div><div><small>{label}</small><strong>{value}</strong></div></div>}
function KeyTable({keys,admin,action}){if(!keys.length)return <div className="empty">No licenses found.</div>;return <div className="tablewrap"><table><thead><tr><th>LICENSE KEY</th><th>STATUS</th><th>EXPIRES</th><th>DEVICE</th>{admin&&<th>ACTIONS</th>}</tr></thead><tbody>{keys.map(k=><tr key={k.id}><td><code>{k.key}</code><button className="iconbtn" title="Copy key" onClick={()=>navigator.clipboard?.writeText(k.key)}><Copy size={14}/></button></td><td><span className={`pill ${k.status}`}>{k.status}</span></td><td>{k.expires_at?new Date(k.expires_at).toLocaleDateString():"—"}</td><td>{k.hwid?<span title={k.hwid}>{k.hwid.slice(0,10)}…</span>:"Unbound"}</td>{admin&&<td className="actions"><button onClick={()=>action(k.status==="banned"?"unban":"ban",k.id)}>{k.status==="banned"?"Unban":"Ban"}</button><button onClick={()=>action("reset",k.id)}>Reset HWID</button></td>}</tr>)}</tbody></table></div>}
export default App;